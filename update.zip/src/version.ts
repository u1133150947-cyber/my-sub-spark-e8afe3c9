// Bumped on each release archive
export const APP_VERSION = "v93";
export const APP_VERSION_DATE = "2026-05-12";
